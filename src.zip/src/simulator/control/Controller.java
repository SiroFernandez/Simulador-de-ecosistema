package simulator.control;

import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import simulator.model.AnimalInfo;
import simulator.model.EcoSysObserver;
import simulator.model.MapInfo;
import simulator.model.Simulator;
import simulator.view.SimpleObjectViewer;
import simulator.view.SimpleObjectViewer.ObjInfo;

public class Controller {
	
	private Simulator sim;
	
	public Controller(Simulator sim) {
		this.sim = sim;
	}
	
	public void loadData(JSONObject data) {
		if (data.has("regions")) {
			regionData(data);
		}
		
		animalData(data);
	}
	
	private void regionData(JSONObject data) {
		JSONArray rArray = data.getJSONArray("regions");
		
		for (int i = 0; i < rArray.length(); i++) {
			JSONObject rObj = rArray.getJSONObject(i); 
			
			JSONArray row = rObj.getJSONArray("row");
			JSONArray col = rObj.getJSONArray("col");
			
			int rf = row.getInt(0);
			int rt = row.getInt(1);
			int cf = col.getInt(0);
			int ct = col.getInt(1);
			
			JSONObject spec = rObj.getJSONObject("spec"); 
			
			for (int r = rf; r <= rt; r++) {
				for (int c = cf; c <= ct; c++) {
					this.sim.setRegion(r, c, spec); 
				}
			}
		}
	}
	
	private void animalData(JSONObject data) {
		JSONArray aArray = data.getJSONArray("animals");
		
		for (int i = 0; i < aArray.length(); i++) {
			JSONObject aObj = aArray.getJSONObject(i);
			
			int amount = aObj.getInt("amount");
			JSONObject spec = aObj.getJSONObject("spec");
			
			for (int j = 0; j < amount; j++) {
				this.sim.addAnimal(spec);
			}
		}
	}
	
	public void run(double t, double dt, boolean sv, OutputStream out) {
		PrintStream p = new PrintStream(out);
		
		JSONObject json = new JSONObject();
		json.put("in", this.sim.asJSON());
		
		SimpleObjectViewer view = null;
		
		if (sv) {  
		   MapInfo m = sim.getMapInfo();  
		   view = new SimpleObjectViewer("[ECOSYSTEM]", m.getWidth(), m.getHeight(), m.getCols(), m.getRows());  
		   view.update(toAnimalsInfo(sim.getAnimals()), sim.getTime(), dt);  
		}
		
		while (this.sim.getTime() < t) {
			this.sim.advance(dt);
			
			if (sv) {
	            view.update(toAnimalsInfo(sim.getAnimals()), sim.getTime(), dt);
	        }
		}
		
		json.put("out", this.sim.asJSON());
		p.println(json.toString(4));
		
		if (sv) {
			view.close();
		}
	}

	private List<ObjInfo> toAnimalsInfo(List<? extends AnimalInfo> animals) {
		List<ObjInfo> ol = new ArrayList<>(animals.size());
		for (AnimalInfo a : animals)
			ol.add(new ObjInfo(a.getGeneticCode(), (int) a.getPosition().getX(), (int) a.getPosition().getY(),(int)Math.round(a.getAge())+2));
		return ol;
	}
	
	public void reset(int cols, int rows, int width, int height) {
		this.sim.reset(cols, rows, width, height);
	}
	
	public void setRegions(JSONObject rs) {
		regionData(rs);
	}
	
	public void advance(double dt) {
		this.sim.advance(dt);
	}
	
	public void addObserver(EcoSysObserver o) {
		this.sim.addObserver(o);
	}
	
	public void removeObserver(EcoSysObserver o) {
		this.sim.removeObserver(o);
	}
}
