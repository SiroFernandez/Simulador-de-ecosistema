package simulator.factories;

import org.json.JSONObject;

import simulator.model.Region;
import simulator.model.DefaultRegion;

public class DefaultRegionBuilder extends Builder<Region>{

	public DefaultRegionBuilder() {
		super("default", "default region");
	}

	
	//----METODOS----
	
	@Override
	protected Region createInstance(JSONObject data) {
		if(data == null) {
			throw new IllegalArgumentException("Data is null in default region");
		}
		return new DefaultRegion();
	}
	
	@Override
	protected void fillInData(JSONObject o) {  
		
	}

}
