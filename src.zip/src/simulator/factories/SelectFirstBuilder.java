package simulator.factories;

import org.json.JSONObject;

import simulator.model.SelectFirst;
import simulator.model.SelectionStrategy;

public class SelectFirstBuilder extends Builder<SelectionStrategy> {

	public SelectFirstBuilder() {
		super("first", "select first strategy");
	}
	
	//----METODOS----

	@Override
	protected SelectionStrategy createInstance(JSONObject data) {
		if(data == null) {
			throw new IllegalArgumentException("Data is null in SelectFirst");
		}
		return new SelectFirst();
	}
}
