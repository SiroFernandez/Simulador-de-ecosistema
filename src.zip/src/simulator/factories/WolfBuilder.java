package simulator.factories;

import org.json.JSONArray;
import org.json.JSONObject;

import simulator.misc.Utils;
import simulator.misc.Vector2D;
import simulator.model.Animal;
import simulator.model.SelectFirst;
import simulator.model.SelectionStrategy;
import simulator.model.Wolf;

public class WolfBuilder extends Builder<Animal>{
	
	private Factory<SelectionStrategy> selectionFactory;

	public WolfBuilder(Factory<SelectionStrategy> selectionFactory) {
		super("wolf", "a wolf");
		
		if (selectionFactory == null) {
			throw new IllegalArgumentException("Selection factory is null in WolfBuilder");
		}
		this.selectionFactory = selectionFactory;
	}
	
	//----METODOS----

	@Override 
	protected Animal createInstance(JSONObject data) {
		
		if (data == null) {
			throw new IllegalArgumentException("Data is null in WolfBuilder");
		}
		
		if(data.length() > 3) {
			throw new IllegalArgumentException("Invalid parameters in Wolf, more arguments than valid");
		}
		
		//Mate strategy
		SelectionStrategy mateStrategy = new SelectFirst();;
		
		if (data.has("mate_strategy")) {
			mateStrategy = this.selectionFactory.createInstance(data.getJSONObject("mate_strategy"));
		}
		
		//Hunt strategy
		SelectionStrategy huntStrategy = new SelectFirst();;
		
		if (data.has("hunt_strategy")) {
			huntStrategy = this.selectionFactory.createInstance(data.getJSONObject("hunt_strategy"));
		}
		
		//Posicion
		Vector2D pos = null; 
		
		if (data.has("pos")) {
			JSONObject posObj = data.getJSONObject("pos");
			JSONArray xRange = posObj.getJSONArray("x_range");
			JSONArray yRange = posObj.getJSONArray("y_range");
			
			double minX = xRange.getDouble(0);
			double maxX = xRange.getDouble(1);
			double minY = yRange.getDouble(0);
			double maxY = yRange.getDouble(1);
			
			double X = Utils.randomInRange(minX, maxX);
			double Y = Utils.randomInRange(minY, maxY);
			
			pos = new Vector2D(X,Y);
		}
		return new Wolf(mateStrategy, huntStrategy, pos);
	}
}
