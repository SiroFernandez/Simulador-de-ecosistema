package simulator.factories;

import org.json.JSONObject;

import simulator.model.SelectYoungest;
import simulator.model.SelectionStrategy;

public class SelectYoungestBuilder extends Builder<SelectionStrategy> {

	public SelectYoungestBuilder() {
		super("youngest", "youngest strategy");
	}
	
	//----METODOS----
	
	@Override
	protected SelectionStrategy createInstance(JSONObject data) {
		if(data == null) {
			throw new IllegalArgumentException("Data is null in SelectYoungest");
		}
		return new SelectYoungest();
	}
}
