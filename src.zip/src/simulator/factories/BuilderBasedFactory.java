package simulator.factories;

import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;

public class BuilderBasedFactory<T> implements Factory<T> { 
	
	private Map<String, Builder<T>> builders; //Mapa de builders
	private List<JSONObject> buildersInfo;

	public BuilderBasedFactory() {
		// Create a HashMap for builders, and a LinkedList buildersInfo 
		this.builders = new HashMap<>();
		this.buildersInfo = new LinkedList<>();
	}

	public BuilderBasedFactory(List<Builder<T>> builders) {  		
		this();
		
		// Call addBuilder(b) for each builder b in builder 
		for (Builder<T> b : builders) {
			addBuilder(b);
		}
	}
	
	//----METODOS----

	public void addBuilder(Builder<T> b) {  
		// Add an entry "b.getTypeTag() |−> b" to builders. 
		this.builders.put(b.getTypeTag(), b);
		
		// Add b.getInfo() to buildersInfo
		this.buildersInfo.add(b.getInfo());
	}

	@Override  
	public T createInstance(JSONObject info) {  
		if (info == null) {  
			throw new IllegalArgumentException("’info’ cannot be null");  
		}
				
		// Look for a builder with a tag equals to info.getString("type"), in the
	    // map _builder, and call its createInstance method and return the result
	    // if it is not null. The value you pass to createInstance is the following
	    // because 'data' is optional:
	    //
	    //   info.has("data") ? info.getJSONObject("data") : new JSONObject()
		
		String type = info.getString("type");
		Builder<T> builder = this.builders.get(type);
		
		if (builder!= null) {
			JSONObject data = info.has("data")? info.getJSONObject("data"): new JSONObject();
	        T instance = builder.createInstance(data);
	        
	        if (instance!= null) {
	            return instance;
	        }
		}	

		// If no builder is found or the result is null ...  
		throw new IllegalArgumentException("Unrecognized ‘info’:" + info.toString());  
	}

	@Override  
	public List<JSONObject> getInfo() {  
		return Collections.unmodifiableList(this.buildersInfo);  
	}
}
