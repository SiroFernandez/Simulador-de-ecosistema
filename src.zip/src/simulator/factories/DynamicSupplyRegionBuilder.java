package simulator.factories;

import org.json.JSONObject;

import simulator.model.DynamicSupplyRegion;
import simulator.model.Region;

public class DynamicSupplyRegionBuilder extends Builder<Region> {
	
	public DynamicSupplyRegionBuilder() {
		super("dynamic", "dynamic supply region");
	}

	//----METODOS---- 
	
	@Override
	protected Region createInstance(JSONObject data) {
		if(data == null) {
			throw new IllegalArgumentException("Data is null in dynamic supply region");
		}
		
		if(data.length() > 2) {
			throw new IllegalArgumentException("Invalid parameters in Dynamic Supply Region, more arguments than valid");
		}
		
		double factor = 2.0;
		double food = 100.0;
		
		if (data.has("factor")) {
			factor = data.getDouble("factor");
		}
		
		//double factor = data.optDouble("factor", 2.0);
		
		if (data.has("food")) {
			food = data.getDouble("food");
		}
		
		return new DynamicSupplyRegion(food, factor);
	}
	
	@Override
	protected void fillInData(JSONObject o) {  
		o.put("factor", "food icrease factor (optional, default 2.0)");
		o.put("food", "initial amount of food (optional, default 100.0)");
	}

}
