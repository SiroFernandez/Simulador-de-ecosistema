package simulator.factories;

import org.json.JSONObject;

import simulator.model.SelectClosest;
import simulator.model.SelectionStrategy;

public class SelectClosestBuilder extends Builder<SelectionStrategy> {

	public SelectClosestBuilder() {
		super("closest", "select closest strategy");
	}
	
	//----METODOS----

	@Override
	protected SelectionStrategy createInstance(JSONObject data) {
		if(data == null) {
			throw new IllegalArgumentException("Data is null in SelectClosest");
		}
		return new SelectClosest();
	}
}
