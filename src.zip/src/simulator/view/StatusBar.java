package simulator.view;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.SwingUtilities;

import simulator.control.Controller;
import simulator.model.AnimalInfo;
import simulator.model.EcoSysObserver;
import simulator.model.MapInfo;
import simulator.model.RegionInfo;

@SuppressWarnings("serial")
class StatusBar extends JPanel implements EcoSysObserver {
	private JLabel timeLabel;
    private JLabel animalsLabel;
    private JLabel dimensionLabel; 

  StatusBar(Controller ctrl) {  
    initGUI();  
    ctrl.addObserver(this); // registrar this como observador  
  }

  private void initGUI() {  
    this.setLayout(new FlowLayout(FlowLayout.LEFT));  
    this.setBorder(BorderFactory.createBevelBorder(1));

    JSeparator s = new JSeparator(JSeparator.VERTICAL);  
    s.setPreferredSize(new Dimension(10, 20));  
    this.add(s);
    
    this.timeLabel = new JLabel("Time: ");
    this.animalsLabel = new JLabel("Animals: ");
    this.dimensionLabel = new JLabel("Dimension: ");
    
    this.add(timeLabel);
    this.add(s);
    this.add(animalsLabel);
    this.add(s);
    this.add(dimensionLabel);
  }

  private void updateValues(double time, MapInfo map, List<AnimalInfo> animals) {
	  this.timeLabel.setText("Time: " + time);
	  this.animalsLabel.setText("Animals: " + animals.size());
	  this.dimensionLabel.setText(String.format("Dimension: %dx%d, %dx%d", map.getWidth(), map.getHeight(), map.getCols(), map.getRows()));
  }
  
  @Override
  public void onRegister(double time, MapInfo map, List<AnimalInfo> animals) {
	  SwingUtilities.invokeLater(() -> {
		  updateValues(time, map, animals);
	  });
	  
  }

  @Override
  public void onReset(double time, MapInfo map, List<AnimalInfo> animals) {
	  SwingUtilities.invokeLater(() -> {
		  updateValues(time, map, animals);
	  });
  }

  @Override
  public void onAnimalAdded(double time, MapInfo map, List<AnimalInfo> animals, AnimalInfo a) {
	  SwingUtilities.invokeLater(() -> {
		  updateValues(time, map, animals);
	  });
  }

  @Override
  public void onRegionSet(int row, int col, MapInfo map, RegionInfo r) {
  }

  @Override
  public void onAdvance(double time, MapInfo map, List<AnimalInfo> animals, double dt) {
	  SwingUtilities.invokeLater(() -> {
		  updateValues(time, map, animals);
	  });
  }
}