package simulator.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.util.Iterator;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

import org.json.JSONArray;
import org.json.JSONObject;

import simulator.control.Controller;
import simulator.launcher.Main;
import simulator.model.AnimalInfo;
import simulator.model.EcoSysObserver;
import simulator.model.MapInfo;
import simulator.model.RegionInfo;

@SuppressWarnings("serial")
class ChangeRegionsDialog extends JDialog implements EcoSysObserver {
	  private DefaultComboBoxModel<String> regionsModel;  
	  private DefaultComboBoxModel<String> fromRowModel;  
	  private DefaultComboBoxModel<String> toRowModel;  
	  private DefaultComboBoxModel<String> fromColModel;  
	  private DefaultComboBoxModel<String> toColModel;

	  private DefaultTableModel dataTableModel;  
	  private Controller ctrl;  
	  private List<JSONObject> regionsInfo;
	  private String[] headers = { "Key", "Value", "Description" };

	  ChangeRegionsDialog(Controller ctrl) {  
	    super((Frame)null, true);  
	    this.ctrl = ctrl;  
	    initGUI();  
	    this.ctrl.addObserver(this);
	  }

	  private void initGUI() {  
		setTitle("Change Regions");  
	    JPanel mainPanel = new JPanel();  
	    mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));  
	    setContentPane(mainPanel);

	    JPanel helpPanel = new JPanel();
	    JLabel helpText = new JLabel("Select a region type, the rows/cols interval, and provide values for the parameters in the Value column (default values are used for parameters with no values).");
	    helpPanel.add(helpText);
	    mainPanel.add(helpPanel);

	    // this.regionsInfo se usará para establecer la información en la tabla  
	    this.regionsInfo = Main.regionFactory.getInfo();

	    // this.dataTableModel es un modelo de tabla que incluye todos los parámetros de la region
	    this.dataTableModel = new DefaultTableModel() {  
	      @Override  
	      public boolean isCellEditable(int row, int column) {  
	        return column == 1; 
	      }  
	    };  
	    this.dataTableModel.setColumnIdentifiers(this.headers);

	    JTable dataTable = new JTable(this.dataTableModel);
	    dataTable.getColumnModel().getColumn(0).setPreferredWidth(100);
		dataTable.getColumnModel().getColumn(1).setPreferredWidth(100);
		dataTable.getColumnModel().getColumn(2).setPreferredWidth(500);
	    JScrollPane scrollPane = new JScrollPane(dataTable);
	    mainPanel.add(scrollPane);

	    // this.regionsModel es un modelo de combobox que incluye los tipos de regiones
	    this.regionsModel = new DefaultComboBoxModel<>();

	    JPanel regionsPanel = new JPanel();
	    regionsPanel.add(new JLabel("Region Type: "));
	    
	    for(JSONObject regionInfo : this.regionsInfo) {
	    	this.regionsModel.addElement(regionInfo.getString("type"));
	    }
	    
	    JComboBox<String> regionsComboBox = new JComboBox<>(this.regionsModel);
	    regionsPanel.add(regionsComboBox);
	    regionsComboBox.addActionListener(e-> {
	    	updateTable(regionsPanel);
	    });

	    // 4 modelos de combobox para this.fromRowModel, this.toRowModel, this.fromColModel y this.toColModel.
	    this.fromRowModel = new DefaultComboBoxModel<>();
	    this.toRowModel = new DefaultComboBoxModel<>();
	    this.fromColModel = new DefaultComboBoxModel<>();
	    this.toColModel = new DefaultComboBoxModel<>();
	    
	    // 4 combobox que usen estos modelos y añadirlos al diálogo.
	    regionsPanel.add(new JLabel(" Row from/to: "));
	    regionsPanel.add(new JComboBox<>(this.fromRowModel));
	    regionsPanel.add(new JComboBox<>(this.toRowModel));
	    
	    regionsPanel.add(new JLabel(" Column from/to: "));
	    regionsPanel.add(new JComboBox<>(this.fromColModel));
	    regionsPanel.add(new JComboBox<>(this.toColModel));
	    
	    mainPanel.add(regionsPanel);

	    // botones OK y Cancel y añadirlos al diálogo.
	    JPanel buttonPanel = new JPanel();
	    buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 20));
	    
	    JButton okButton = new JButton("OK");
	    okButton.addActionListener(e->{
	    	try {
	    		//Obtener info de la tabla como JSON
	    		JSONObject data = getJSON();
	    		
	    		//Obtener tipo de region seleccionada
	    		String regionType = (String) this.regionsModel.getSelectedItem();
	    		
	    		//Obtener coordenadas comboBox
	    		int rowFrom = Integer.parseInt((String) this.fromRowModel.getSelectedItem());
	    		int rowTo = Integer.parseInt((String) this.toRowModel.getSelectedItem());
				int colFrom = Integer.parseInt((String) this.fromColModel.getSelectedItem());
				int colTo = Integer.parseInt((String) this.toColModel.getSelectedItem());
				
				//Crear JSON
				JSONObject regionsJson = new JSONObject();
				JSONObject regionInfo = new JSONObject();
				JSONObject spec = new JSONObject();
				
				JSONArray regionsArray = new JSONArray();
				JSONArray rowArray = new JSONArray();
				JSONArray colArray = new JSONArray();
				
				rowArray.put(rowFrom);
				rowArray.put(rowTo);
				colArray.put(colFrom);
				colArray.put(colTo);
				regionInfo.put("col", colArray);
				regionInfo.put("row", rowArray);
				
				spec.put("type", regionType);
				spec.put("data", data);
				regionInfo.put("spec", spec);
				
				regionsArray.put(regionInfo);
				regionsJson.put("regions", regionsArray);
				
				//Llamar al this.ctrl.setRegions
				this.ctrl.setRegions(regionsJson);
				
				setVisible(false);
	    		
	    	} catch(Exception ex){
	    		ViewUtils.showErrorMsg(ex.getMessage());
	    	}
	    });
	    
	    JButton cancelButton = new JButton("Cancel");
	    cancelButton.addActionListener(e->{
	    	setVisible(false);
	    });
	    
	    buttonPanel.add(cancelButton);
		buttonPanel.add(okButton);
	    
	    mainPanel.add(buttonPanel, BorderLayout.SOUTH);

	    setPreferredSize(new Dimension(950, 400));
	    pack();  
	    setResizable(false);  
	    setVisible(false);  
	    
	    if(this.regionsModel.getSize() > 0) {
			updateTable(regionsPanel);
		}
	  }

	  public void open(Frame parent) {
	    setLocation(
	      parent.getLocation().x + parent.getWidth() / 2 - getWidth() / 2,
	      parent.getLocation().y + parent.getHeight() / 2 - getHeight() / 2);
	    pack();  
	    setVisible(true);  
	  }
	  
	  private void resetLimits() {
		  this.fromRowModel.removeAllElements();
		  this.toRowModel.removeAllElements();
		  this.fromColModel.removeAllElements();
		  this.toColModel.removeAllElements();
	  }
	  
	  private void getLimits(int rows, int cols) {
		  for(int i = 0; i < rows; i++) {
			  this.fromRowModel.addElement(Integer.toString(i));
			  this.toRowModel.addElement(Integer.toString(i));
		  }
		  
		  for(int i = 0; i < cols; i++) {
			  this.fromColModel.addElement(Integer.toString(i));
			  this.toColModel.addElement(Integer.toString(i));
		  }
	  }
	  
	  private void updateTable(JPanel table) {
		  //Limpia la tabla
		  this.dataTableModel.setRowCount(0);
		  
		  //Obtiene info de las regiones
		  this.regionsInfo = Main.regionFactory.getInfo();
		  
		  //Buscar JSON de la region buscada
		  JSONObject region = null;
		  for(JSONObject j : this.regionsInfo) {
			  if(j.getString("type").equals(this.regionsModel.getSelectedItem())) {
				  region = j;
			  }
		  }
		  
		  if(region == null)
			  return;
		  
		  //Obtener JSON para la region buscada
		  JSONObject data = region.getJSONObject("data");
		  
		  //Reccorrer JSON y agregarlo a la tabla
		  Iterator<String> it = data.keys();
		  while(it.hasNext()) {
			  String key = it.next();
			  this.dataTableModel.addRow(new Object[] {key, null, data.getString(key)});
		  }
		  
		  //Mostrar cambios
		  table.revalidate();
	  }
	  
	  private JSONObject getJSON() {
		  JSONObject regionData = new JSONObject();
		  
		  for(int i = 0; i < this.dataTableModel.getRowCount(); i++) {
			  String key = this.dataTableModel.getValueAt(i, 0).toString();
			  String value = "";
			  
			  if(this.dataTableModel.getValueAt(i, 1) != null) {
				  value = this.dataTableModel.getValueAt(i, 1).toString();
			  }
			  
			  if(!value.isEmpty()) {
				  regionData.put(key,  JSONObject.stringToValue(value));
			  }
		  }
		  
		  return regionData;
	  }

	  @Override
	  public void onRegister(double time, MapInfo map, List<AnimalInfo> animals) {
		  SwingUtilities.invokeLater(() -> {
			  resetLimits();
			  getLimits(map.getRows(), map.getCols());
		  });
	  }

	  @Override
	  public void onReset(double time, MapInfo map, List<AnimalInfo> animals) {
		  SwingUtilities.invokeLater(() -> {
			  resetLimits();
			  getLimits(map.getRows(), map.getCols());
		  });
	  }

	  @Override
	  public void onAnimalAdded(double time, MapInfo map, List<AnimalInfo> animals, AnimalInfo a) {
		
	  }

	  @Override
	  public void onRegionSet(int row, int col, MapInfo map, RegionInfo r) {
		
	  }

	  @Override
	  public void onAdvance(double time, MapInfo map, List<AnimalInfo> animals, double dt) {
		
	  }
	  
}