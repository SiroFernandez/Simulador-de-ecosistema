package simulator.view;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.SwingUtilities;
import javax.swing.table.AbstractTableModel;

import simulator.control.Controller;
import simulator.model.AnimalInfo;
import simulator.model.Diet;
import simulator.model.EcoSysObserver;
import simulator.model.MapInfo;
import simulator.model.MapInfo.RegionData;
import simulator.model.RegionInfo;

@SuppressWarnings("serial")
public class RegionsTableModel extends AbstractTableModel implements EcoSysObserver{
	private Controller ctrl;
	private List<ArrayList<Object>> regions;
	
	RegionsTableModel(Controller ctrl) {  
		// inicializar estructuras de datos correspondientes  
	    // registrar this como observador
		this.ctrl = ctrl;
		this.regions = new ArrayList<>();
		this.ctrl.addObserver(this);
	}  
	
	@Override
	public int getRowCount() {
		return this.regions.size();
	}

	@Override
	public int getColumnCount() {
		return 3 + Diet.values().length; // Hay tres columnas antes
	}
	
	@Override
	public String getColumnName(int column) {
		if (column == 0) {
			return "Row";
		} else if (column == 1) {
			return "Column";
		} else if (column == 2) {
			return "Description";
		} else {
			return Diet.values()[column - 3].toString();
		}
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		return this.regions.get(rowIndex).get(columnIndex);
	}
	
	private void updateRegions(MapInfo map) {
		this.regions.clear();
		
		if (map != null) {
			for (RegionData region : map) {
				ArrayList<Object> datos = new ArrayList<>();
				
				datos.add(region.row());
				datos.add(region.col());
				datos.add(region.r().toString());
				
				// Inicializar contadores a 0
				for (Diet diet : Diet.values()) {
					datos.add(0);
				}
				
				// Contar animales por dieta
				List<AnimalInfo> animals = region.r().getAnimalsInfo();
				if (animals != null) {
					for (AnimalInfo a : animals) {
						if (a != null && a.getDiet() != null) {
							int index = a.getDiet().ordinal() + 3;
							datos.set(index, (int) datos.get(index) + 1);
						}
					}
				}
				
				this.regions.add(datos);
			}
		}
		
		fireTableDataChanged();
	}

	@Override
	public void onRegister(double time, MapInfo map, List<AnimalInfo> animals) {
		SwingUtilities.invokeLater(() -> {
			updateRegions(map);
		});
	}

	@Override
	public void onReset(double time, MapInfo map, List<AnimalInfo> animals) {
		SwingUtilities.invokeLater(() -> {
			updateRegions(map);
		});
	}

	@Override
	public void onAnimalAdded(double time, MapInfo map, List<AnimalInfo> animals, AnimalInfo a) {
		SwingUtilities.invokeLater(() -> {
			updateRegions(map);
		});
	}

	@Override
	public void onRegionSet(int row, int col, MapInfo map, RegionInfo r) {
		SwingUtilities.invokeLater(() -> {
			updateRegions(map);
		});
	}

	@Override
	public void onAdvance(double time, MapInfo map, List<AnimalInfo> animals, double dt) {
		SwingUtilities.invokeLater(() -> {
			updateRegions(map);
		});
	}

}
