package simulator.view;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.SwingUtilities;
import javax.swing.table.AbstractTableModel;

import simulator.control.Controller;
import simulator.model.AnimalInfo;
import simulator.model.EcoSysObserver;
import simulator.model.MapInfo;
import simulator.model.RegionInfo;
import simulator.model.State;

@SuppressWarnings("serial")
public class SpeciesTableModel extends AbstractTableModel implements EcoSysObserver{
	private Controller ctrl;
	private Map<String, Map<State, Integer>> species;
	private List<String> speciesList;
	
	SpeciesTableModel(Controller ctrl) {  
		// inicializar estructuras de datos correspondientes  
		// registrar this como observador   
		this.ctrl = ctrl;
		this.species = new HashMap<>();
		this.speciesList = new ArrayList<>();
		this.ctrl.addObserver(this);
	}
	
	@Override
	public int getRowCount() {
		return this.speciesList.size();	
	}

	@Override
	public int getColumnCount() {
		return State.values().length + 1; //Probar el +1 para no problema con codigo genetico
	}
	
	@Override
	public String getColumnName(int column) {
		if (column == 0) {
			return "Species";
		} else {
			State[] states = State.values();
			return states[column - 1].toString();
		}
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		String species = speciesList.get(rowIndex);
		
		if(columnIndex == 0) {
			return species;
		}
		else {
			return this.species.get(species).getOrDefault(State.values()[columnIndex - 1], 0);
		}
	}
	
	private void initSpecies(List<AnimalInfo> animals){
		for (AnimalInfo animalInfo : animals) {
			String type = animalInfo.getGeneticCode();		
			if(!this.species.containsKey(type)) {
				this.species.put(type, new HashMap<>());
				this.speciesList.add(type);
				for(State state : State.values()) {
					this.species.get(type).put(state, 0);
				}
			}
		}
	}
	
	private void resetValues() {
		for(Map<State, Integer> map : this.species.values()) {
			for(State state : State.values()) {
				map.put(state, 0);
			}
		}
	}
	
	private void advanceSpecies(List<AnimalInfo> animals) {
		for(AnimalInfo animalInfo : animals) {
			String type = animalInfo.getGeneticCode();
			State state = animalInfo.getState();		
			
			this.species.get(type).put(state, this.species.get(type).get(state) + 1);
		}
		fireTableDataChanged();
	}

	@Override
	public void onRegister(double time, MapInfo map, List<AnimalInfo> animals) {
		SwingUtilities.invokeLater(() -> {
			initSpecies(animals);
			advanceSpecies(animals);
		});
		
	}

	@Override
	public void onReset(double time, MapInfo map, List<AnimalInfo> animals) {
		SwingUtilities.invokeLater(() -> {
			this.species.clear();
			this.speciesList.clear();
			initSpecies(animals);
			advanceSpecies(animals);
		});
	}

	@Override
	public void onAnimalAdded(double time, MapInfo map, List<AnimalInfo> animals, AnimalInfo a) {
		SwingUtilities.invokeLater(() -> {
			initSpecies(animals);
			resetValues();       
			advanceSpecies(animals);
		});
	}

	@Override
	public void onRegionSet(int row, int col, MapInfo map, RegionInfo r) {
		
	}

	@Override
	public void onAdvance(double time, MapInfo map, List<AnimalInfo> animals, double dt) {
		SwingUtilities.invokeLater(() -> {
			resetValues();
			advanceSpecies(animals);
		});
	}

}
