package simulator.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;

import org.json.JSONObject;
import org.json.JSONTokener;

import simulator.control.Controller;
import simulator.launcher.Main;

@SuppressWarnings("serial")
public class ControlPanel extends JPanel{
  private Controller ctrl;  
  private ChangeRegionsDialog changeRegionsDialog;

  private JToolBar toolaBar;  
  private JFileChooser fc;  
    
  private JTextField dText;
  private JSpinner stepsText;
  private double dt;
  private int steps;
  
  private JButton quitButton;
  private JButton openButton;
  private JButton viewerButton;
  private JButton regionsButton;
  private JButton runButton;
  private JButton stopButton;
  
  //Cambios practica 3
  private volatile Thread thread;
  private JSpinner delay;
  //Opcional 
  private SwingWorker<Void, Void> worker;
  private JComboBox<String> runMode;
  private boolean stopped = true; //Solo para modo NORMAL



  ControlPanel(Controller ctrl) {  
    this.ctrl = ctrl;  
    initGUI();  
  }

  private void initGUI() {  
    setLayout(new BorderLayout());  
    toolaBar = new JToolBar();  
    add(toolaBar, BorderLayout.PAGE_START);
    
    //----OPEN BUTTON----
    //this.toolaBar.add(Box.createGlue()); // this aligns the button to the right  
    this.toolaBar.addSeparator();  
    this.openButton = new JButton();  
    this.openButton.setToolTipText("Open");  
    this.openButton.setIcon(new ImageIcon("resources/icons/open.png"));  
    this.openButton.addActionListener((e) -> {
    	int v = fc.showOpenDialog(ViewUtils.getWindow(this));
    	if (v == JFileChooser.APPROVE_OPTION) {
    		File f = fc.getSelectedFile();
    		try {
    			JSONObject j = loadJSON(f);
        		ctrl.reset(j.getInt("cols"), j.getInt("rows"), j.getInt("width"), j.getInt("height"));
        		ctrl.loadData(j);
    		} catch (Exception ex) {
    			ViewUtils.showErrorMsg("HA HABIDO ERROR AL ABRIR FICHERO " + ex.getMessage());
    		}
    	}
    });
    this.toolaBar.add(openButton);

    //----MAP VIEWER BUTTON----
    //this.toolaBar.add(Box.createGlue()); // this aligns the button to the right  
    this.toolaBar.addSeparator();  
    this.viewerButton = new JButton();  
    this.viewerButton.setToolTipText("Viewer");  
    this.viewerButton.setIcon(new ImageIcon("resources/icons/viewer.png"));  
    this.viewerButton.addActionListener((e) -> {
    	MapWindow m = new MapWindow(ViewUtils.getWindow(this), this.ctrl);
    	m.open(ViewUtils.getWindow(this));
    });
    this.toolaBar.add(viewerButton);
    
    //----MAP REGIONS BUTTON----
    //this.toolaBar.add(Box.createGlue()); // this aligns the button to the right  
    //this.toolaBar.addSeparator();  
    this.regionsButton = new JButton();  
    this.regionsButton.setToolTipText("Regions");  
    this.regionsButton.setIcon(new ImageIcon("resources/icons/regions.png"));  
    this.regionsButton.addActionListener((e) -> {
    	this.changeRegionsDialog.open(ViewUtils.getWindow(this));
    });
    this.toolaBar.add(regionsButton);
    
    //----RUN BUTTON----
    //this.toolaBar.add(Box.createGlue()); // this aligns the button to the right  
    this.toolaBar.addSeparator();  
    this.runButton = new JButton();  
    this.runButton.setToolTipText("Run");  
    this.runButton.setIcon(new ImageIcon("resources/icons/run.png"));  
    
    this.runButton.addActionListener((e) -> {
    	this.dt = Double.valueOf(dText.getText());
    	this.steps = (int) this.stepsText.getValue();
    	int delay = (int) this.delay.getValue();
    	String mode = (String) this.runMode.getSelectedItem();
    	turnOffButtons();
    	
    	if ("NORMAL".equals(mode)) {
        	this.stopped = false;
    		runSim(this.steps, this.dt);
    	}
    	else if ("THREAD".equals(mode)) {
    		this.thread = new Thread(() -> runSimThread(this.steps, this.dt, delay));
    		this.thread.start();
    	}
    	else if ("WORKER".equals(mode)) {
    		runSimWorker(this.steps, this.dt, delay);
    	}
    	
//    	this.thread = new Thread(() -> {
//    		runSim(steps, dt, delay);
//
//    		SwingUtilities.invokeLater(() -> {
//    			turnOnButtons();
//    			this.thread = null;
//    		});
//    	});
//
//    	this.thread.start();
    });
    
    this.toolaBar.add(runButton);
    
    //----STOP BUTTON----
    //this.toolaBar.add(Box.createGlue()); // this aligns the button to the right  
    //this.toolaBar.addSeparator();  
    this.stopButton = new JButton();  
    this.stopButton.setToolTipText("Stop");  
    this.stopButton.setIcon(new ImageIcon("resources/icons/stop.png"));  
    
    this.stopButton.addActionListener((e) -> {
    	//Modo NORMAL
    	this.stopped = true;
    	
    	//THREAD
    	if (this.thread != null) {
    		this.thread.interrupt();
    	}
    	
    	//WORKER
    	if (this.worker != null) {
    		this.worker.cancel(true);
    	}
    });
    this.toolaBar.add(stopButton);
    this.toolaBar.add(Box.createRigidArea(new Dimension(10, 0)));
    
    //----STEPS----
    //this.toolaBar.addSeparator();  
    this.toolaBar.add(new javax.swing.JLabel(" Steps:"));
    //this.toolaBar.add(Box.createGlue()); // this aligns the button to the right  
    this.stepsText = new JSpinner (new SpinnerNumberModel(10000, 0, 20000, 100));
    this.stepsText.setMaximumSize(new Dimension(80, 30));
    this.stepsText.setMinimumSize(new Dimension(80, 30));
    this.stepsText.setPreferredSize(new Dimension(80, 30));
    this.toolaBar.add(stepsText);
    this.toolaBar.add(Box.createRigidArea(new Dimension(10, 0)));
    
    //----DELTA-TIME----
    //this.toolaBar.addSeparator();  
    this.toolaBar.add(new javax.swing.JLabel(" Delta-Time:"));
    //this.toolaBar.add(Box.createGlue()); // this aligns the button to the right  
    this.dText = new JTextField (String.valueOf(Main.deltaTime));
    this.dText.setMaximumSize(new Dimension(50, 30));
    this.dText.setMinimumSize(new Dimension(50, 30));
    this.dText.setPreferredSize(new Dimension(50, 30));
    this.toolaBar.add(dText);
    
    //----DELAY----
    this.toolaBar.add(new javax.swing.JLabel(" Delay:"));
    this.delay = new JSpinner(new SpinnerNumberModel(1, 0, 1000, 1));
    this.delay.setMaximumSize(new Dimension(80, 30));
    this.delay.setMinimumSize(new Dimension(80, 30));
    this.delay.setPreferredSize(new Dimension(80, 30));
    this.toolaBar.add(delay);
    this.toolaBar.add(Box.createRigidArea(new Dimension(10, 0)));
    
    //----MODE----
    this.toolaBar.add(new javax.swing.JLabel("Mode: "));
    this.runMode = new JComboBox<>(new String[]{"NORMAL", "THREAD", "WORKER"});
    this.runMode.setMaximumSize(new Dimension(100, 30));
    this.toolaBar.add(runMode);
    this.toolaBar.add(Box.createRigidArea(new Dimension(10, 0)));
    
    //----QUIT BUTTON----
    this.toolaBar.add(Box.createGlue()); // this aligns the button to the right  
    this.toolaBar.addSeparator();  
    this.quitButton = new JButton();  
    this.quitButton.setToolTipText("Quit");  
    this.quitButton.setIcon(new ImageIcon("resources/icons/exit.png"));  
    this.quitButton.addActionListener((e) -> ViewUtils.quit(this));  
    this.toolaBar.add(quitButton);
    
    // Inicializar this.fc con una instancia de JFileChooser. Para que siempre  
    // abre en la carpeta de ejemplos puedes usar:  
    this.fc = new JFileChooser();
    this.fc.setCurrentDirectory(new File(System.getProperty("user.dir") + "/resources/examples"));
   
    // Inicializar this.changeRegionsDialog con instancias del diálogo de cambio   
    // de regiones   
    this.changeRegionsDialog = new ChangeRegionsDialog(ctrl);

  }   
  
  // el resto de métodos van aquí…
  private JSONObject loadJSON(File file) throws Exception{
	try(FileInputStream fis = new FileInputStream(file)){
		return new JSONObject(new JSONTokener(fis));
	}
  }
  
  //Modo NORMAL
  private void runSim(int n, double dt) {  
	 if (n > 0 && !this.stopped) {  
	   try {  
		   this.ctrl.advance(dt);  
	       SwingUtilities.invokeLater(() -> runSim(n - 1, dt));  
	   } catch (Exception e) {
		   ViewUtils.showErrorMsg("HA HABIDO ERROR EN EJECUCION");
	       turnOnButtons();
	       this.stopped = true;  
	   }  
	 } 
	 
	 else {  
	   turnOnButtons();
	   this.stopped = true;  
	 }  
  }
  
  //THREAD
  private void runSimThread(int n, double dt, int delay) {
	  try {
      while (n > 0 && !Thread.currentThread().isInterrupted()) {
        ctrl.advance(dt);
        if (Thread.currentThread().isInterrupted()) {
        	break;
        }
        Thread.sleep(delay);
        n--;
      }

    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
    } catch (Exception e) {
      SwingUtilities.invokeLater(() ->
        ViewUtils.showErrorMsg(e.getMessage())
      );
      return;
    } finally {
      SwingUtilities.invokeLater(() -> {
        turnOnButtons();
        thread = null;
      });
    }
  }
  
  //WORKER
  private void runSimWorker(int n, double dt, int delay) {
      this.worker = new SwingWorker<Void, Void>() {
          @Override
          protected Void doInBackground() throws Exception {
              int stepsLeft = n;
              while (stepsLeft > 0 && !isCancelled()) {
            	  try {
            		  ctrl.advance(dt);
            		  if (isCancelled()) {
            			  return null;
            		  }
                      Thread.sleep(delay);
                      stepsLeft--;
            	  } catch (InterruptedException e) {
            		  return null;
            	  } catch (Exception e) {
            		  SwingUtilities.invokeLater(() ->
                      ViewUtils.showErrorMsg(e.getMessage())
                  );
                  return null;
            	  }
              }
              return null;
          }

          @Override
          protected void done() {
              turnOnButtons();
              worker = null;
          }
      };
      this.worker.execute(); 
  }
  
  private void turnOffButtons() {
	  List<JButton> buttons = new ArrayList<>();
	  buttons.add(openButton);
	  buttons.add(regionsButton);
	  buttons.add(viewerButton);
	  buttons.add(runButton);
	  buttons.add(quitButton);

	  for (JButton button : buttons) {
		  button.setEnabled(false);
	  }
  }
  
  private void turnOnButtons() {
	  List<JButton> buttons = new ArrayList<>();
	  buttons.add(openButton);
	  buttons.add(regionsButton);
	  buttons.add(viewerButton);
	  buttons.add(runButton);
	  buttons.add(quitButton);
	  buttons.add(stopButton);

	  for (JButton button : buttons) {
		  button.setEnabled(true);
	  }
  }
}
