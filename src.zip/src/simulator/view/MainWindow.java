package simulator.view;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;

import simulator.control.Controller;

@SuppressWarnings("serial")
public class MainWindow extends JFrame {
	private Controller ctrl;
	
	public MainWindow(Controller ctrl) {  
	    super("[ECOSYSTEM SIMULATOR]");  
	    this.ctrl = ctrl;  
	    initGUI();  
	}

    private void initGUI() {  
	    JPanel mainPanel = new JPanel(new BorderLayout());  
	    setContentPane(mainPanel);
	
	    // TODO crear ControlPanel y añadirlo en PAGE_START de mainPanel
	    ControlPanel controlPanel = new ControlPanel(this.ctrl);
		mainPanel.add(controlPanel, BorderLayout.PAGE_START);
	    
	    // TODO crear StatusBar y añadirlo en PAGE_END de mainPanel  
		StatusBar statusBar = new StatusBar(this.ctrl);
		mainPanel.add(statusBar, BorderLayout.PAGE_END);
	
	    // Definición del panel de tablas (usa un BoxLayout vertical)  
	    JPanel contentPanel = new JPanel();  
	    contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));  
	    mainPanel.add(contentPanel, BorderLayout.CENTER);
	
	    // TODO crear la tabla de especies y añadirla a contentPanel.  
	    //      Usa setPreferredSize(new Dimension(500, 250)) para fijar su tamaño
	    InfoTable speciesTable = new InfoTable("Species", new SpeciesTableModel(this.ctrl));
	    speciesTable.setPreferredSize(new Dimension(500, 250));
	    contentPanel.add(speciesTable);
	
	    // TODO crear la tabla de regiones.  
	    //      Usa setPreferredSize(new Dimension(500, 250)) para fijar su tamaño
	    InfoTable regionsTable = new InfoTable("Regions", new RegionsTableModel(this.ctrl));
	    regionsTable.setPreferredSize(new Dimension(500, 250));
	    contentPanel.add(regionsTable);
	    
	    // TODO llama a ViewUtils.quit(MainWindow.this) en el método windowClosing
	    addWindowListener(new java.awt.event.WindowAdapter() {
	    	@Override
	    	public void windowClosing(java.awt.event.WindowEvent windowEvent) {
	    		ViewUtils.quit(MainWindow.this);
	    	}
	    });
	
	    setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);  
	    pack();  
	    setVisible(true);  
   }  
}
