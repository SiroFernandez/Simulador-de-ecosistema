package simulator.view;

import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import simulator.control.Controller;
import simulator.model.AnimalInfo;
import simulator.model.EcoSysObserver;
import simulator.model.MapInfo;
import simulator.model.RegionInfo;

@SuppressWarnings("serial")
class MapWindow extends JFrame implements EcoSysObserver {

	  private Controller ctrl;  
	  private AbstractMapViewer viewer;  
	  private Frame parent;

	  MapWindow(Frame parent, Controller ctrl) {  
	    super("[MAP VIEWER]");  
	    this.ctrl = ctrl;  
	    this.parent = parent;  
	    intiGUI();  
	    this.ctrl.addObserver(this);
	  }

	  private void intiGUI() {  
	    JPanel mainPanel = new JPanel(new BorderLayout());  
	    //Poner contentPane como mainPanel
	    setContentPane(mainPanel);

	    //Crear el viewer y añadirlo a mainPanel (en el centro)
	    this.viewer = new MapViewer();
	    mainPanel.add(this.viewer, BorderLayout.CENTER);

	    //Método windowClosing, eliminar ‘MapWindow.this’ de los observadores
	    addWindowListener(new WindowListener() {

			@Override
			public void windowOpened(WindowEvent e) {
				
			}

			@Override
			public void windowClosing(WindowEvent e) {
				ctrl.removeObserver(MapWindow.this);
			}

			@Override
			public void windowClosed(WindowEvent e) {
				
			}

			@Override
			public void windowIconified(WindowEvent e) {
				
			}

			@Override
			public void windowDeiconified(WindowEvent e) {
				
			}

			@Override
			public void windowActivated(WindowEvent e) {
				
			}

			@Override
			public void windowDeactivated(WindowEvent e) {
				
			} 
	    	
	    });

//	    pack();
//	    
//	    setLocation(
//	    		parent.getLocation().x + parent.getWidth() / 2 - getWidth() / 2,
//		        parent.getLocation().y + parent.getHeight() / 2 - getHeight() / 2);
//		setResizable(false);  
//      setVisible(true); 
	  }
	  
	  public void open(Frame parent) {
		    this.parent = parent;

		    pack();
		    center();

//		    setLocation(
//		        parent.getLocation().x + parent.getWidth() / 2 - getWidth() / 2,
//		        parent.getLocation().y + parent.getHeight() / 2 - getHeight() / 2
//		    );

		    setResizable(false);
		    setVisible(true);
	  }
	  
	  private void center() {
		    if (parent != null) {
		        setLocation(
		            parent.getLocation().x + parent.getWidth() / 2 - getWidth() / 2,
		            parent.getLocation().y + parent.getHeight() / 2 - getHeight() / 2
		        );
		    }
		}

	  @Override
	  public void onRegister(double time, MapInfo map, List<AnimalInfo> animals) {
		SwingUtilities.invokeLater(() -> { 
			this.viewer.reset(time, map, animals); 
			pack(); 
			center();
		});
	  }

	  @Override
	  public void onReset(double time, MapInfo map, List<AnimalInfo> animals) {
		SwingUtilities.invokeLater(() -> {
			this.viewer.update(animals, time);
			pack();
			center();
		});
	  }

	  @Override
	  public void onAnimalAdded(double time, MapInfo map, List<AnimalInfo> animals, AnimalInfo a) {
		
	  }

	  @Override
	  public void onRegionSet(int row, int col, MapInfo map, RegionInfo r) {
		
	  }

	  @Override
	  public void onAdvance(double time, MapInfo map, List<AnimalInfo> animals, double dt) {
		SwingUtilities.invokeLater(() -> {
			this.viewer.update(animals, time);
			//pack();
		    //center();
		});
	  }  
	}