package simulator.launcher;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.swing.SwingUtilities;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.json.JSONObject;
import org.json.JSONTokener;

import simulator.factories.Builder;
import simulator.misc.Utils;
import simulator.model.Animal;
import simulator.model.Region;
import simulator.model.SelectionStrategy;
import simulator.model.Simulator;
import simulator.view.MainWindow;
import simulator.control.Controller;
import simulator.factories.*;

public class Main {

	private enum ExecMode {
		BATCH("batch", "Batch mode"), GUI("gui", "Graphical User Interface mode");

		private String tag;
		private String desc;

		private ExecMode(String modeTag, String modeDesc) {
			tag = modeTag;
			desc = modeDesc; 
		}
		
		//----GETTERS----

		public String getTag() {
			return tag;
		}

		public String getDesc() {
			return desc;
		}
	}

	// default values for some parameters
	private final static Double DEFAULT_TIME = 10.0; // in seconds

	// some attributes to stores values corresponding to command-line parameters
	private static Double time = null;
	private static String inFile = null;
	private static ExecMode mode = ExecMode.BATCH;
	
	private static String outFile = null;
	private static boolean simpleViewer = false;
	public static double deltaTime = 0.03;
	
	public static Factory<Region> regionFactory;
	public static Factory<Animal> animalFactory;
	
	//----METODOS----
	
	private static void parseArgs(String[] args) {

		// define the valid command line options
		Options cmdLineOptions = buildOptions();

		// parse the command line as provided in args
		CommandLineParser parser = new DefaultParser();
		
		try {
			CommandLine line = parser.parse(cmdLineOptions, args);
			parseModeOption(line);
			parseDeltaTimeOption(line);
			parseHelpOption(line, cmdLineOptions);
			parseInFileOption(line);
			parseOutFileOption(line);
			parseSimpleViewerOption(line);
			parseTimeOption(line);

			// if there are some remaining arguments, then something wrong is
			// provided in the command line!
			String[] remaining = line.getArgs();
			if (remaining.length > 0) {
				String error = "Illegal arguments:";
				for (String o : remaining)
					error += (" " + o);
				throw new ParseException(error);
			}

		} catch (ParseException e) {
			System.err.println(e.getLocalizedMessage());
			System.exit(1);
		}

	}

	private static Options buildOptions() {
		Options cmdLineOptions = new Options();
		
		//Delta time
		cmdLineOptions.addOption(Option.builder("dt").longOpt("delta-time").hasArg().desc("A double representing actual time, in seconds, per simulation step. Default value: 0.03.").build());

		// help
		cmdLineOptions.addOption(Option.builder("h").longOpt("help").desc("Print this message.").build());

		// input file
		cmdLineOptions.addOption(Option.builder("i").longOpt("input").hasArg().desc("A configuration file.").build());

		//output file
		cmdLineOptions.addOption(Option.builder("o").longOpt("output").hasArg().desc("Output file, where output is written.").build());
		
		//Viewer window
		cmdLineOptions.addOption(Option.builder("sv").longOpt("simple-viewer").desc("Show the viewer window in console mode.").build());
		
		// steps
		cmdLineOptions.addOption(Option.builder("t").longOpt("time").hasArg().desc(
				"A real number representing the total simulation time in seconds. Default value: " + DEFAULT_TIME + ".")
				.build());
		
		//Use in Batch mode
		cmdLineOptions.addOption(Option.builder("m").longOpt("mode").hasArg().desc(
				"Execution Mode. Possible values: 'batch' (Batch mode), gui (Graphical User Interface mode).Default value: gui.")
				.build());
		
		return cmdLineOptions;
	}

	private static void parseHelpOption(CommandLine line, Options cmdLineOptions) {
		if (line.hasOption("h")) {
			HelpFormatter formatter = new HelpFormatter();
			formatter.printHelp(Main.class.getCanonicalName(), cmdLineOptions, true);
			System.exit(0);
		}
	}

	private static void parseInFileOption(CommandLine line) throws ParseException {
		inFile = line.getOptionValue("i");
		
		if (mode == ExecMode.BATCH && inFile == null) {
			throw new ParseException("In batch mode an input configuration file is required");
		}
	}

	private static void parseTimeOption(CommandLine line) throws ParseException {
		String t = line.getOptionValue("t", DEFAULT_TIME.toString());
		try {
			time = Double.parseDouble(t);
			assert (time >= 0);
		} catch (Exception e) {
			throw new ParseException("Invalid value for time: " + t);
		}
	}

	private static void parseSimpleViewerOption(CommandLine line) {
		simpleViewer = line.hasOption("sv");
	}

	private static void parseOutFileOption(CommandLine line) throws ParseException {
		outFile = line.getOptionValue("o");
		
		if (mode == ExecMode.BATCH && outFile == null) {
			throw new ParseException("In batch mode an output configuration file is required");
		}
	}

	private static void parseDeltaTimeOption(CommandLine line) throws ParseException {
		String dt = line.getOptionValue("dt", "0.03");
		try {
			deltaTime = Double.parseDouble(dt);
			assert (deltaTime >= 0); //verifica que deltaTime sea >= 0
		} catch (Exception e) {
			throw new ParseException("Invalid value for delta time: " + dt);
		}
	}
	
	private static void parseModeOption(CommandLine line) throws ParseException{
		String m = line.getOptionValue("m", "gui");
		if ("gui".equals(m)) {
			mode = ExecMode.GUI;
		} else if ("batch".equals(m)) {
			mode = ExecMode.BATCH;
		}
		else {
			throw new ParseException("Error in the mode value");
		}
	}
	
	private static void initFactories() {
		//Inicializar las factorías y almacenarlas en los atributos correspondientes.
		
		//Estrategias
		List<Builder<SelectionStrategy>> selectionBuilder = new ArrayList<>();
		selectionBuilder.add(new SelectFirstBuilder());
		selectionBuilder.add(new SelectClosestBuilder());
		selectionBuilder.add(new SelectYoungestBuilder());
		Factory<SelectionStrategy> selectionFactory = new BuilderBasedFactory<>(selectionBuilder);
		
		//Regiones
		List<Builder<Region>> regionBuilder = new ArrayList<>();
		regionBuilder.add(new DefaultRegionBuilder());
		regionBuilder.add(new DynamicSupplyRegionBuilder());
		regionFactory = new BuilderBasedFactory<>(regionBuilder);
		
		//Animales
		List<Builder<Animal>> animalBuilder = new ArrayList<>();
		animalBuilder.add(new SheepBuilder(selectionFactory));
		animalBuilder.add(new WolfBuilder(selectionFactory));
		animalFactory = new BuilderBasedFactory<>(animalBuilder);
	}

	private static JSONObject loadJSONFile(InputStream in) {
		return new JSONObject(new JSONTokener(in));
	}

	private static void startBatchMode() throws Exception {
		InputStream is = new FileInputStream(new File(inFile));
		JSONObject data = loadJSONFile(is);
		
		int width = data.getInt("width");
		int height = data.getInt("height");
		int rows = data.getInt("rows");
		int cols = data.getInt("cols");
		
		Simulator simulator = new Simulator(width, height, cols, rows, animalFactory, regionFactory);
		Controller controller = new Controller(simulator);
		
		OutputStream out;
		
		if (outFile != null) {
			out = new FileOutputStream(new File(outFile));
		}
		else {
			out = System.out;
		}
		
		controller.loadData(data);
		controller.run(time, deltaTime, simpleViewer, out);
		
		is.close();
		
		if (outFile != null) {
		    out.close();
		}
	}

	private static void startGUIMode() throws Exception {
		System.out.println("GUI");
		Simulator simulator;
		Controller controller;
		
		if(inFile != null) {
			InputStream is = new FileInputStream(new File(inFile));
			JSONObject inputJSON = loadJSONFile(is);

			int width = inputJSON.getInt("width");
			int height = inputJSON.getInt("height");
			int rows = inputJSON.getInt("rows");
			int cols = inputJSON.getInt("cols");

			simulator = new Simulator(cols, rows, width, height, animalFactory, regionFactory);
			controller = new Controller(simulator);
			
			try {
				controller.loadData(inputJSON);
			} catch (IllegalArgumentException e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
		} else {
			simulator = new Simulator(20, 15, 800, 600, animalFactory, regionFactory);
			controller = new Controller(simulator);
		}
		
		SwingUtilities.invokeLater(() -> new MainWindow(controller));
	}

	private static void start(String[] args) throws Exception {
		initFactories();
		parseArgs(args);
		switch (mode) {
		case BATCH:
			startBatchMode();
			break;
		case GUI:
			startGUIMode();
			break;
		}
	}

	public static void main(String[] args) {
		Utils.RAND.setSeed(2147483647l);
		try {
			start(args);
		} catch (Exception e) {
			System.err.println("Something went wrong ...");
			System.err.println();
			e.printStackTrace();
		}
	}
}
