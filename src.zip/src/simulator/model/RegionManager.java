package simulator.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.function.Predicate;

import org.json.JSONArray;
import org.json.JSONObject;

public class RegionManager implements AnimalMapView {

	private int width; 
	private int height; 
	private int cols;
	private int rows;
	private int regionWidth;
	private int regionHeight;
	private Region[][] regions; 
	private Map<Animal, Region> animalRegion; 

	public RegionManager(int cols, int rows, int width, int height) {
		this.width = width;
		this.height = height;
		this.cols = cols;
		this.rows = rows;
		this.regionWidth = this.width / this.cols; 
		this.regionHeight = this.height / this.rows;
		this.animalRegion = new HashMap<>();
		this.regions = new Region[rows][cols]; 
		for (int r = 0; r < rows; r++) {
			for (int c = 0; c < cols; c++) {
				this.regions[r][c] = new DefaultRegion(); 
			}
		}		
	}

	//----GETTERS---- 

	@Override
	public int getCols() {
		return this.cols;
	}

	@Override
	public int getRows() {
		return this.rows;
	}

	@Override
	public int getRegionWidth() {
		return this.regionWidth;
	}

	@Override
	public int getRegionHeight() {
		return this.regionHeight;
	}

	@Override
	public double getFood(AnimalInfo a, double dt) {
		Region region = animalRegion.get(a);

		if (region == null) {
			return 0.0;
		}

		return region.getFood(a, dt);
	}

	@Override
	public int getWidth() {
		return this.width;
	}

	@Override
	public int getHeight() {
		return this.height;
	}

	@Override
	public List<Animal> getAnimalsInRange(Animal e, Predicate<Animal> filter) {
		List<Animal> list = new ArrayList<>();
		
		int x1 = Math.max(0, (int) ((e.getPos().getX() - e.getSightRange()) / this.regionWidth));
	    int x2 = Math.min(this.cols - 1, (int) ((e.getPos().getX() + e.getSightRange()) / this.regionWidth));
	    int y1 = Math.max(0, (int) ((e.getPos().getY() - e.getSightRange()) / this.regionHeight));
	    int y2 = Math.min(this.rows - 1, (int) ((e.getPos().getY() + e.getSightRange()) / this.regionHeight));
		
		for (int i = y1; i <= y2; i++) {
			for (int j = x1; j <= x2; j++) {
				for (Animal animal : this.regions[i][j].getAnimals()) {
					if (animal != e && filter.test(animal)) { 
						double distance = e.getPos().distanceTo(animal.getPos());
						if (distance <= e.getSightRange()) {
							list.add(animal);
						}
					}
				}
			}
		}

		return list;
	}

	//----SETTERS----

	protected void setRegion(int row, int col, Region r) {
		Region oldRegion = regions[row][col];

		this.regions[row][col] = r;

		for (Animal a: oldRegion.getAnimals()) {
			r.addAnimal(a);
			//oldRegion.removeAnimal(a);
			animalRegion.put(a, r);
		}
	}

	
	//----METODOS----

	@Override
    public Iterator<RegionData> iterator() {
		// Iterador que recorre la matriz de regiones (por filas, de izquierda a derecha)
		// y para cada region devuelve una instancia correspondiente de RegionData
		
        return new Iterator<RegionData>() {
			//Se crea un iterador anónino para definir cómo se recorre la estructura sin tener que 
			//crear una clase aparte.
			//Sobreescrible el comportamiento para que la clase sea iterable, es decir, usable en un for-each
        	
	        private int currentRow = 0;
	        private int currentCol = 0;
	
	        @Override
	        public boolean hasNext() {
	        	//Devuelve true si quedan filas por recorrer
	            return currentRow < getRows();
	        }
	
	        @Override
	        public RegionData next() {
	        	//Si no quedan filas por recorrer
	            if (!hasNext()) {
	                throw new NoSuchElementException("No hay más regiones disponibles.");
	            }
	
	            RegionInfo regionInfo = regions[currentRow][currentCol];
	            RegionData regionData = new RegionData(currentRow, currentCol, regionInfo);
	
	            currentCol++;
	            
	            if (currentCol >= getCols()) {
	                currentCol = 0;
	                currentRow++;
	            }
	            return regionData;
	        }
        };
    }

	protected void registerAnimal(Animal a) {

		a.init(this);

		int r = Math.min((int) (a.getPos().getY() / this.regionHeight), rows - 1);
		int c= Math.min((int)(a.getPos().getX() / this.regionWidth), cols - 1);
		Region region = this.regions[r][c];
		region.addAnimal(a); 
		this.animalRegion.put(a, region);
		//a.init(this);
	}

	protected void unregisterAnimal(Animal a) {
		Region region = this.animalRegion.get(a); 
		region.removeAnimal(a);
		this.animalRegion.remove(a); 
	}

	protected void updateAnimalRegion(Animal a) {
		int r = Math.min((int) (a.getPos().getY() / this.regionHeight), rows - 1);
		int c= Math.min((int)(a.getPos().getX() / this.regionWidth), cols - 1);
		Region region = this.regions[r][c];
		Region prevRegion = this.animalRegion.get(a);

		if (region != prevRegion) {
			region.addAnimal(a);
			prevRegion.removeAnimal(a);
			this.animalRegion.put(a, region);
		}
	}

	protected void updateAllRegions(double dt) {
		for (int i = 0; i < this.rows; i++) {
			for (int j = 0; j < this.cols; j++) {
				this.regions[i][j].update(dt);
			}
		}
	}

	public JSONObject asJSON() {
		JSONObject json = new JSONObject();
		JSONArray rmArray = new JSONArray();		

		for (int i = 0; i < this.rows; i++) {
			for (int j = 0; j < this.cols; j++) {
				JSONObject regionJson = new JSONObject();
				regionJson.put("row", i);
				regionJson.put("col", j);
				regionJson.put("data", this.regions[i][j].asJSON());

				rmArray.put(regionJson);
			}
		}
		json.put("regions", rmArray);
		return json;
	}
}
