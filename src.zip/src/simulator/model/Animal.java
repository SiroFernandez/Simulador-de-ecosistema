package simulator.model;

import simulator.misc.Vector2D;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import simulator.misc.Utils;

public abstract class Animal implements Entity, AnimalInfo{
	
	final static double MAX_ENERGY = 100.0;
	final static double MAX_DESIRE = 100.0;
	
	private String geneticCode;
	private Diet diet;
	private State state;
	private Vector2D pos;
	private Vector2D dest;
	private double energy;
	private double speed;
	private double age;
	private double desire;
	private double sightRange;
	private Animal mateTarget;
	private Animal baby;
	private AnimalMapView regionMngr;
	private SelectionStrategy mateStrategy;
	
	protected Animal(String geneticCode, Diet diet, double sightRange, double initSpeed, SelectionStrategy mateStrategy, Vector2D pos) {
		if (initSpeed <= 0) {
			throw new IllegalArgumentException("Initial speed: Must be a positive value");
		} 
		if (sightRange <= 0) {
			throw new IllegalArgumentException("Sight range: Must be a positive value");
		}
		this.setGeneticCode(geneticCode);
		this.setDiet(diet);
		this.state = State.NORMAL;
		this.setPos(pos);
		this.setDest(null);
		this.setEnergy(100.0);
		this.setSpeed(Utils.getRandomizedParameter(initSpeed, 0.1));
		this.setDesire(0.0);
		this.setSightRange(sightRange);
		this.setMateStrategy(mateStrategy);
		this.setMateTarget(null);
		this.setBaby(null);
		this.setRegionMngr(null);
		this.setAge(0.0);
	}
	
	protected Animal(Animal p1, Animal p2) {
		if (p1 == null || p2 == null) {
			throw new IllegalArgumentException("p1 or p2 is null");
		}
		this.setDest(null);
		this.setBaby(null);
		this.setMateTarget(null);
		this.setRegionMngr(null);
		this.setState(State.NORMAL);
		this.setDesire(0.0);
		this.setGeneticCode(p1.getGeneticCode());
		this.setDiet(p1.getDiet());
		this.setMateStrategy(p2.getMateStrategy());
		this.setEnergy((p1.getEnergy() + p2.getEnergy()) / 2);
		this.setPos(p1.getPosition().plus(Vector2D.get_random_vector(-1,1).scale(60.0*(Utils.RAND.nextGaussian()+1))));
		this.setSightRange(Utils.getRandomizedParameter((p1.getSightRange()+p2.getSightRange())/2, 0.2));
		this.setSpeed(Utils.getRandomizedParameter((p1.getSpeed()+p2.getSpeed())/2, 0.2));
		this.setAge(0.0);
	}
	
	//----GETTERS----
	
	abstract public double getMaxAge();
	abstract public double getEnergyModifier();
	abstract public double getDesireModifier();
	abstract public double getSpeedModifier();
	
	public String getGeneticCode() {
		return this.geneticCode;
	}

	public Diet getDiet() {
		return this.diet;
	}

	public State getState() {
		return this.state;
	}

	public Vector2D getPos() {
		return this.pos;
	}

	public Vector2D getDest() {
		return this.dest;
	}

	public double getEnergy() {
		return this.energy;
	}

	public double getSpeed() {
		return this.speed;
	}

	public double getAge() {
		return this.age;
	}

	public double getDesire() {
		return this.desire;
	}

	public double getSightRange() {
		return this.sightRange;
	}

	public Animal getMateTarget() {
		return this.mateTarget;
	}

	public Animal getBaby() {
		return this.baby;
	}

	public AnimalMapView getRegionMngr() {
		return this.regionMngr;
	}

	public SelectionStrategy getMateStrategy() {
		return this.mateStrategy;
	}
	
	//----SETTERS----
	
	protected void setGeneticCode(String geneticCode) {
		if (geneticCode == null || geneticCode.isEmpty()) {
			throw new IllegalArgumentException("Genetic code: Null value");		
		}
		this.geneticCode = geneticCode;
	}

	protected void setDiet(Diet diet) {
		if (diet == null) {
			throw new IllegalArgumentException("Diet: Null value");		
		}
		this.diet = diet;
	}

	protected void setPos(Vector2D pos) {
		this.pos = pos;
	}

	protected void setDest(Vector2D dest) {
		this.dest = dest;
	}

	protected void setEnergy(double energy) {
		if(energy < 0.0) {
			this.energy = 0.0;
		}
		else if(energy > MAX_ENERGY) {
			this.energy = MAX_ENERGY;
		}
		else {
			this.energy = energy;
		}
	}

	protected void setSpeed(double speed) {
		if (speed <= 0) {
			throw new IllegalArgumentException("Speed: Must be a positive value");		
		}
		this.speed = speed;
	}

	protected void setAge(double age) {
		if (age < 0) {
			throw new IllegalArgumentException("Age: Must be a positive value");		
		}
		this.age = age;
	}

	protected void setDesire(double desire) {
		if(desire < 0.0) {
			this.desire = 0.0;
		}
		else if(desire > MAX_DESIRE) {
			this.desire = MAX_DESIRE;
		}
		else {
			this.desire = desire;
		}
	}

	protected void setSightRange(double sightRange) {
		if (sightRange <= 0) {
			throw new IllegalArgumentException("Sight range: Must be a positive value");		
		}
		this.sightRange = sightRange;
	}

	protected void setMateTarget(Animal mateTarget) {
		this.mateTarget = mateTarget;
	}

	protected void setBaby(Animal baby) {
		this.baby = baby;
	}

	protected void setRegionMngr(AnimalMapView regionMngr) {
		this.regionMngr = regionMngr;
	}

	protected void setMateStrategy(SelectionStrategy mateStrategy) {
		if (mateStrategy == null) {
			throw new IllegalArgumentException("Mate strategy: Null value");		
		}
		this.mateStrategy = mateStrategy;
	}
	
	protected void setState(State state) {
		this.state = state;
	  	switch (state) {
	  	case NORMAL:
	  		setNormalStateAction();
	  		break;
	  	case MATE:
	  		setMateStateAction();
	  		break;
	  	case HUNGER:
	  		setHungerStateAction();
	  		break;
	  	case DANGER:
	  		setDangerStateAction();
	  		break;
	  	case DEAD:
	  		setDeadStateAction();
	  		break;  
	  	}
	}
	
	//----METODOS----
	
	abstract void updateState(double dt);
	
	protected void adjustPosition() {
		double x = getPos().getX();
		double y = getPos().getY();
		double width = getRegionMngr().getWidth();
		double height = getRegionMngr().getHeight();
		
		while (x >= width) x = (x - width);  
		while (x < 0) x = (x + width);  
		while (y >= height) y = (y - height);  
		while (y < 0) y = (y + height);
		
		setPos(new Vector2D(x, y));
	}
	
	@Override
	public boolean isPregnant() {
		return getBaby() != null;
	}
	
	@Override
	public void update(double dt) {
		if (getState() == State.DEAD) {
			return;
		}
		
		updateState(dt);
		adjustPosition();
		
		if (getEnergy() == 0.0 || getAge() > getMaxAge()) {
			setState(State.DEAD);
		}
		
		if (getState() != State.DEAD) {
			double food = getRegionMngr().getFood(this, dt);
			setEnergy(Utils.constrainValueInRange(getEnergy() + food, 0.0, 100.0));
		}
		
	}
	
	public void init(AnimalMapView regMngr) {
		this.setRegionMngr(regMngr);
		
	    double x, y;
		
		double width = this.regionMngr.getWidth();
		double height = this.regionMngr.getHeight();
		
		if (this.getPos() == null) {
			x = Utils.RAND.nextDouble() * (width-1);
			y = Utils.RAND.nextDouble() * (height-1);
			
 		}
		else {
			x = this.getPos().getX();
		    y = this.getPos().getY();
		    
			while (x >= width) x = (x - width);  
			while (x < 0) x = (x + width);  
			while (y >= height) y = (y - height);  
			while (y < 0) y = (y + height);
			
		}
		
		this.setPos(new Vector2D(x,y));
		
		double destX = Utils.RAND.nextDouble() * (width-1);
		double destY = Utils.RAND.nextDouble() * (height-1);
		
		this.setDest(new Vector2D(destX, destY));
	}
	
	public Animal deliverBaby() {
		Animal baby = this.getBaby();
		this.setBaby(null);
		return baby;
	}
	
	protected void move(double speed) {
		this.setPos(pos.plus(dest.minus(pos).direction().scale(speed)));
	}
	
	protected void moveToTarget(double dt, Vector2D target) {
		setDest(target);
		move(getSpeedModifier() * getSpeed() * dt * Math.exp((getEnergy() - 100.0) * 0.007));
		setAge(getAge() + dt);
		setEnergy(Utils.constrainValueInRange(getEnergy() - getEnergyModifier() * 1.2 * dt, 0.0, 100.0));
		setDesire(Utils.constrainValueInRange(getDesire() + getDesireModifier() * dt, 0.0, 100.0));
	}
	
	protected void walk(double dt) {
		if (getPos().distanceTo(getDest()) < 8.0) {
			setDest(new Vector2D(Utils.RAND.nextDouble() * getRegionMngr().getWidth(),
								 Utils.RAND.nextDouble() * getRegionMngr().getHeight()));
		}
		
		move(getSpeed() * dt * Math.exp((getEnergy() - 100.0) * 0.007));
		setAge(getAge() + dt);
		
		setEnergy(Utils.constrainValueInRange(getEnergy() - getEnergyModifier() * dt, 0.0, 100.0));
		setDesire(Utils.constrainValueInRange(getDesire() + getDesireModifier() * dt, 0.0, 100.0));
	}
	
	protected void searchPartner() {
		List<Animal> partners = getRegionMngr().getAnimalsInRange(this, a -> a != this && a.getGeneticCode().equals(this.getGeneticCode()));
		
		if (!partners.isEmpty()) {
			setMateTarget(getMateStrategy().select(this, partners));
		}
		else {
			setMateTarget(null);
		}
	}
	
	public JSONObject asJSON() {
		JSONObject json = new JSONObject();
		JSONArray posArray = new JSONArray();
		posArray.put(this.getPos().getX());
		posArray.put(this.getPos().getY());
		
		json.put("pos", posArray);
		json.put("gcode", this.getGeneticCode());
		json.put("diet", this.getDiet().toString());
		json.put("state", this.getState().toString());
		
		return json;
	}
		
	abstract protected void setNormalStateAction(); 
	
	abstract protected void setMateStateAction();
	
	abstract protected void setHungerStateAction();
	
	abstract protected void setDangerStateAction();
	
	abstract protected void setDeadStateAction();
}
