package simulator.model;

import java.util.List;

import simulator.misc.Utils;
import simulator.misc.Vector2D;

public class Sheep extends Animal{
	
	final static String SHEEP_GENETIC_CODE = "Sheep";
	final static double SHEEP_MAX_AGE = 8.0;
	final static double SHEEP_ENERGY = 20.0;
	final static double SHEEP_DESIRE = 40.0;
	final static double SHEEP_SPEED = 2.0;
	
	private Animal dangerSource;
	private SelectionStrategy dangerStrategy;
	
	public Sheep(SelectionStrategy mateStrategy, SelectionStrategy dangerStrategy,  Vector2D pos) {
		super(SHEEP_GENETIC_CODE, Diet.HERBIVORE, 40.0, 35.0, mateStrategy, pos);
		this.dangerSource = null;
		this.dangerStrategy = dangerStrategy;
	}

	protected Sheep(Sheep p1, Animal p2) {
		super(p1, p2);
		this.dangerStrategy = p1.dangerStrategy;
		this.dangerSource = null;
	}
	
	//----GETTERS----
	
	@Override
	public Vector2D getPosition() {
		return getPos();
	}

	@Override
	public Vector2D getDestination() {
		return getDest();
	}
	
	@Override
	public double getMaxAge() {
		return SHEEP_MAX_AGE;
	}
	
	@Override
	public double getEnergyModifier() {
		return SHEEP_ENERGY;
	}
	
	@Override
	public double getDesireModifier() {
		return SHEEP_DESIRE;
	}

	@Override
	public double getSpeedModifier() {
		return SHEEP_SPEED;
	}
	
	//----SETTERS----

	@Override
	protected void setNormalStateAction() {
		setMateTarget(null);
		this.dangerSource = null;
		
	}

	@Override
	protected void setMateStateAction() {
		this.dangerSource = null;
		
	}

	@Override
	protected void setHungerStateAction() {
		throw new IllegalArgumentException("Sheep no puede estar en estado hunger");
	}

	@Override
	protected void setDangerStateAction() {
		setMateTarget(null);
	}

	@Override
	protected void setDeadStateAction() {
		setMateTarget(null);
		this.dangerSource = null;
	}
	
	//----METODOS----
	
	@Override
	protected void updateState(double dt) {
		switch(getState()) {
		case NORMAL:
			updateNormal(dt);
			break;
		case DANGER:
			updateDanger(dt);
			break;
		case MATE:
			updateMate(dt);
			break;
		case HUNGER:
			setState(State.NORMAL);
			break;
		default:
			break;
	}
	}
	
	private void updateNormal(double dt) {
		
		walk(dt);
		
		if (this.dangerSource == null) {
			searchDangerousAnimal();
		}
		
		if (this.dangerSource != null){
			setState(State.DANGER);
		}
		
		else if (getDesire() > 65.0) {
			setState(State.MATE);
		}
	}
	
	private void updateDanger(double dt) {
		
		if (this.dangerSource != null && this.dangerSource.getState() == State.DEAD) {
			this.dangerSource = null; //Ya se ha muerto y, por tanto, ya no es peligroso
		}
		
		if (this.dangerSource == null) {
			walk(dt);
		}
		else {
			moveToTarget(dt,getPos().plus(getPos().minus(this.dangerSource.getPosition()).direction()));
		}
		
		if (this.dangerSource == null || (getPos().distanceTo(this.dangerSource.getPosition()) > getSightRange())) {
			searchDangerousAnimal();
		}
		
		if (this.dangerSource == null) {
			if (getDesire() < 65.0) {
				setState(State.NORMAL);
			}
			else {
				setState(State.MATE);
			}
		}
	}
	
	private void updateMate(double dt) {
				
		if (getMateTarget() != null && (getMateTarget().getState() == State.DEAD || getPos().distanceTo(getMateTarget().getPosition()) > getSightRange())) {
			setMateTarget(null);
		}
		
		if (getMateTarget() == null) {
			searchPartner();
		}
		
		if (getMateTarget() == null) {
			walk(dt);
		}
		else {
			moveToTarget(dt,getMateTarget().getPosition());
			
			if (getPos().distanceTo(getMateTarget().getPosition()) < 8.0) {
				setDesire(0.0);
				getMateTarget().setDesire(0.0);
				if (getBaby() == null && Utils.RAND.nextDouble() < 0.9) {
					setBaby(new Sheep(this, getMateTarget()));
				}
				setMateTarget(null);
			}
		}
		
		if (this.dangerSource == null) {
			searchDangerousAnimal();
		}
		
		if (this.dangerSource != null){
			setState(State.DANGER);
		}
		else if (getDesire() < 65.0){
			setState(State.NORMAL);
		}
	}
	
	private void searchDangerousAnimal() {
		List<Animal> dangerousAnimals = getRegionMngr().getAnimalsInRange(this, a -> a.getDiet() == Diet.CARNIVORE); //Uso de expresion lambda
		
		if (!dangerousAnimals.isEmpty()) {
			this.dangerSource = this.dangerStrategy.select(this, dangerousAnimals);
		}
		else {
			this.dangerSource = null;
		}
	}
}
