package simulator.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.json.JSONObject;

import simulator.factories.Factory;

public class Simulator implements JSONable, Observable<EcoSysObserver> {
	
	private Factory<Animal> animalsFactory;
	private Factory<Region> regionsFactory;
	private RegionManager regionMngr;
	private List<Animal> animals;
	private double time;
	private List<EcoSysObserver> observers;
	
	public Simulator(int width, int height, int cols, int rows, Factory<Animal> animalsFactory, Factory<Region> regionsFactory) {
		this.animalsFactory = animalsFactory;
		this.regionsFactory = regionsFactory;
		this.regionMngr = new RegionManager(cols, rows, width, height);
		this.animals = new ArrayList<>();
		this.observers = new ArrayList<>();
		this.time = 0.0;
	}
	
	//----GETTERS----
	
	public double getTime() {
		return this.time;
	}
	
	public MapInfo getMapInfo() {
		return this.regionMngr;
	}
	
	//----SETTERS----
	
	private void setRegion(int row, int col, Region r) {
		this.regionMngr.setRegion(row, col, r);
		onRegionSetObserver(row, col, r);
	}
	
	public void setRegion(int row, int col, JSONObject rJson) {
		Region R = this.regionsFactory.createInstance(rJson);
		setRegion(row, col, R);
	}
	
	//----METODOS----
	
	private void addAnimal(Animal a) {
		this.animals.add(a);
		this.regionMngr.registerAnimal(a);
		onAnimalAddedObserver(a);
	}
	
	public void addAnimal(JSONObject aJson) {
		Animal A = this.animalsFactory.createInstance(aJson);
		addAnimal(A);
	}
	
	public List<? extends AnimalInfo> getAnimals(){
		return Collections.unmodifiableList(this.animals);
	}
	
	public void advance(double dt) {
		increaseTime(dt);
		
		List<Animal> deadAnimals = new ArrayList<>();
		for (Animal a: this.animals) {
			if (a.getState() == State.DEAD) {
				this.regionMngr.unregisterAnimal(a);
				deadAnimals.add(a);
			}
		}
		
		this.animals.removeAll(deadAnimals);
		
		for (Animal a: this.animals) {
			a.update(dt);
			this.regionMngr.updateAnimalRegion(a);
		}
		
		this.regionMngr.updateAllRegions(dt);
		
		List<Animal> babies = new ArrayList<>();
		
		for (Animal a: this.animals) {
			if (a.isPregnant()) {
				Animal baby = a.deliverBaby();
				babies.add(baby);
			}
		}
		
		for (Animal baby: babies) {
			addAnimal(baby);
		}
		
		onAdvanceObserver(dt);
	}
	
	private void increaseTime(double dt) {
		this.time += dt;
	}
	
	public JSONObject asJSON() {
		JSONObject json = new JSONObject();
		
		json.put("time", getTime());
		json.put("state", this.regionMngr.asJSON());
		
		return json;
	}
	
	public void reset(int cols, int rows, int width, int height) {
		this.animals = new ArrayList<>();
		this.regionMngr = new RegionManager(cols, rows, width, height);
		this.time = 0.0;
		onResetObserver();
	}
	
	public void addObserver(EcoSysObserver o) {
		if(!this.observers.contains(o)) {
			this.observers.add(o);
			o.onRegister(getTime(), getMapInfo(), new ArrayList<>(this.animals));
		}
	}
	
	public void removeObserver(EcoSysObserver o) {
		this.observers.remove(o);
	}
	
	private void onResetObserver() {
		for(EcoSysObserver o : observers) {
			o.onReset(getTime(), getMapInfo(), new ArrayList<>(this.animals));
		}
	}
	
	private void onAnimalAddedObserver(AnimalInfo a) {
		for(EcoSysObserver o : observers) {
			o.onAnimalAdded(getTime(), getMapInfo(), new ArrayList<>(this.animals), a);
		}
	}
	
	private void onRegionSetObserver(int row, int col, RegionInfo r) {
		for(EcoSysObserver o : observers) {
			o.onRegionSet(row, col, getMapInfo(), r);
		}
	}
	
	private void onAdvanceObserver(double dt) {
		//Se puede hacer así para pasar la lista: List<AnimalInfo> animals = new ArrayList<>(this.animals);
		for(EcoSysObserver o : observers) {
			o.onAdvance(getTime(), getMapInfo(), new ArrayList<>(this.animals), dt);
		}
	}
}
