package simulator.model;

import java.util.List;

public class SelectClosest implements SelectionStrategy {

	@Override
	public Animal select(Animal a, List<Animal> as) {
		if (as.isEmpty()) {
			return null;
		}
		
		Animal closest = null;
		double distance;
		double minDistance = Double.MAX_VALUE;
		
		for (Animal animal : as) {
			distance = a.getPosition().distanceTo(animal.getPosition());
			
			if (distance < minDistance) {
				minDistance = distance;
				closest = animal;
			}
		}
		return closest;
	}
}
