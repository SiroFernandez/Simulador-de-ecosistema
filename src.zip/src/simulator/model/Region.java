package simulator.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

public abstract class Region implements Entity, FoodSupplier, RegionInfo {
	protected List<Animal> animals;
	
	public Region() {
		this.animals = new ArrayList<Animal>();
	}
	
	//----GETTERS----
	
	protected final List<Animal> getAnimals(){
		return Collections.unmodifiableList(this.animals); 
	}
	
	public List<AnimalInfo> getAnimalsInfo() {  
		  return new ArrayList<>(animals); // se puede usar Collections.unmodifiableList(animals);  
	}
	
	//----METODOS----
	
	protected final void addAnimal(Animal a) {
		this.animals.add(a);
	}
	
	protected final void removeAnimal(Animal a) {
		this.animals.remove(a);
	}
	
	public JSONObject asJSON() {
		JSONObject json = new JSONObject();
		JSONArray aArray = new JSONArray();
		
		for (Animal a: this.animals) {
			aArray.put(a.asJSON());
		}
		
		json.put("animals", aArray);
				
		return json;
	}
	
	protected int numHerbivores() {
		int cont = 0;
		for (Animal a: this.animals) {
			if (a.getDiet() == Diet.HERBIVORE) {
				cont++;
			}
		}
		return cont;
	}
}
