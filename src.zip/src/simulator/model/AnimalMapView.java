package simulator.model;

import java.util.List;
import java.util.function.Predicate;

public interface AnimalMapView extends MapInfo, FoodSupplier {
	
	//----GETTERS----
	
	public int getWidth();

	public int getHeight();
	
	public double getFood(AnimalInfo a, double dt);
	
	public List<Animal> getAnimalsInRange(Animal e, Predicate<Animal> filter);
}
