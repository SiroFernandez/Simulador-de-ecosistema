package simulator.model;

import simulator.misc.Utils;

public class DynamicSupplyRegion extends Region {
	
	private double food;
	private double factor;
	final static String NAME = "DynamicRegion";
	
	public DynamicSupplyRegion(double iniFood, double factor){
		if (iniFood <= 0) {
			throw new IllegalArgumentException("Initial food must be a positive number");
		}
		if (factor < 0) {
			throw new IllegalArgumentException("dt must be a no negative number");
		}
		this.food = iniFood;
		this.factor = factor;
	}
	
	//----GETTERS----
	
	@Override
	public double getFood(AnimalInfo a, double dt) {
		if (a.getDiet() == Diet.CARNIVORE) {
			return 0.0;
		}
		else {
			double foodGiven = Math.min(this.food, 60.0 * Math.exp(- Math.max(0, numHerbivores() - 5.0) * 2.0) * dt);
			this.food = this.food - foodGiven;
			
			return foodGiven;
		}
	}
	
	
	//----METODOS---- 
	
	@Override
	public void update(double dt) {
		if (Utils.RAND.nextDouble() < 0.5) {
			this.food = this.food + this.factor * dt;
		}
	}
	
	@Override
	public String toString() {
		return NAME;
	}
}
