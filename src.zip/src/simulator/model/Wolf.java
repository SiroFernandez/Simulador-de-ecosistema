package simulator.model;

import java.util.List;

import simulator.misc.Utils;
import simulator.misc.Vector2D;

public class Wolf extends Animal{
	
	final static String WOLF_GENETIC_CODE = "Wolf";
	final static double WOLF_MAX_AGE = 14.0;
	final static double WOLF_ENERGY = 18.0;
	final static double WOLF_DESIRE = 30.0;
	final static double WOLF_SPEED = 3.0;

	private Animal huntTarget;
	private SelectionStrategy huntingStrategy;
	
	public Wolf(SelectionStrategy mateStrategy, SelectionStrategy huntingStrategy,  Vector2D pos) {
		super(WOLF_GENETIC_CODE, Diet.CARNIVORE, 50.0, 60.0, mateStrategy, pos);
		this.huntingStrategy = huntingStrategy;
		this.huntTarget = null;
	}

	protected Wolf(Wolf p1, Animal p2) {
		super(p1, p2);
		this.huntingStrategy = p1.huntingStrategy;
		this.huntTarget = null;
	}
	
	//----GETTERS----
	
	@Override
	public Vector2D getPosition() {
		return getPos();
	}

	@Override
	public Vector2D getDestination() {
		return getDest();
	}
	
	@Override
	public double getMaxAge() {
		return WOLF_MAX_AGE;
	}
	
	@Override
	public double getEnergyModifier() {
		return WOLF_ENERGY;
	}
	
	@Override
	public double getDesireModifier() {
		return WOLF_DESIRE;
	}
	
	@Override
	public double getSpeedModifier() {
		return WOLF_SPEED;
	}
	
	//----SETTERS----
	
	@Override
	protected void setNormalStateAction() {
		this.huntTarget = null;
		setMateTarget(null);
		
	}

	@Override
	protected void setMateStateAction() {
		this.huntTarget = null;
	}

	@Override
	protected void setHungerStateAction() {
		setMateTarget(null);
	}

	@Override
	protected void setDangerStateAction() {
		throw new IllegalArgumentException("Wolf no puede estar en estado danger");
	}

	@Override
	protected void setDeadStateAction() {
		setMateTarget(null);
		this.huntTarget = null;
	}
	
	//----METODOS---- 
	
	@Override
	protected void updateState(double dt) {
		switch(getState()) {
		case NORMAL:
			updateNormal(dt);
			break;
		case HUNGER:
			updateHunger(dt);
			break;
		case MATE:
			updateMate(dt);
			break;
		case DANGER:
			setState(State.NORMAL);
			break;
		default:
			break;
		}
	}
	
	private void updateNormal(double dt) {
		
		walk(dt);
		
		if (getEnergy() < 50.0) {
			setState(State.HUNGER);
		}
		else if (getDesire() > 65.0) {
			setState(State.MATE);
		}
	}
	
	private void updateHunger(double dt) {
		
		if (this.huntTarget == null || (this.huntTarget != null && this.huntTarget.getState() == State.DEAD)
			|| (this.getPos().distanceTo(this.huntTarget.getPosition()) > getSightRange())) {
			searchPrey();
		}
		
		if (this.huntTarget == null) {
			walk(dt);
		}
		else {
			moveToTarget(dt, this.huntTarget.getPosition());
			
			if (getPos().distanceTo(this.huntTarget.getPosition()) < 8.0) {
				this.huntTarget.setState(State.DEAD);
				this.huntTarget = null;
				setEnergy(Utils.constrainValueInRange(getEnergy() + 50.0, 0.0, 100.0));
			}
		}
		
		if (getEnergy() > 50.0) {
			
			if (getDesire() < 65.0){
				setState(State.NORMAL);
			}
			else {
				setState(State.MATE);
			}
		}
	}
	
	private void updateMate(double dt) {
				
		if (getMateTarget() != null && (getMateTarget().getState() == State.DEAD || getPos().distanceTo(getMateTarget().getPosition()) > getSightRange())) {
			setMateTarget(null);
		}
		
		if (getMateTarget() == null) {
			searchPartner();
		}
		
		if (getMateTarget() == null) {
			walk(dt);
		}
		else {
			moveToTarget(dt, getMateTarget().getPosition());
			
			if (getPos().distanceTo(getMateTarget().getPosition()) < 8.0) {
				setDesire(0.0);
				getMateTarget().setDesire(0.0);
				
				if (getBaby() == null && Utils.RAND.nextDouble() < 0.75) {
					setBaby(new Wolf(this, getMateTarget()));
				}
				setEnergy(Utils.constrainValueInRange(getEnergy() - 10.0, 0.0, 100.0));
				setMateTarget(null);
			}
		}
		
		if (getEnergy() < 50.0) {
			setState(State.HUNGER);
		}
		else if (getDesire() < 65.0) {
			setState(State.NORMAL);
		}
	}
	
	private void searchPrey() {
		List<Animal> preys = getRegionMngr().getAnimalsInRange(this, a -> a.getDiet() == Diet.HERBIVORE); //Uso de expresion lambda
		
		if (!preys.isEmpty()) {
			this.huntTarget = this.huntingStrategy.select(this, preys);
		}
		else {
			this.huntTarget = null;
		}
	}
}
