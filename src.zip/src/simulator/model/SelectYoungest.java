package simulator.model;

import java.util.List;

public class SelectYoungest implements SelectionStrategy {

	@Override
	public Animal select(Animal a, List<Animal> as) {
		if (as.isEmpty()) {
			return null;
		}
		
		Animal youngest = null;
		double minAge = Double.MAX_VALUE;
		
		
		for (Animal animal : as) {
			if (animal.getAge() < minAge) {
				minAge = animal.getAge();
				youngest = animal;
			}
		}
		return youngest;
	}
}
